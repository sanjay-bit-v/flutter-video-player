enum PlayingState {
  initializing,
  initialized,
  stopped,
  paused,
  ended,
  buffering,
  playing,
  recording,
  error,
}
