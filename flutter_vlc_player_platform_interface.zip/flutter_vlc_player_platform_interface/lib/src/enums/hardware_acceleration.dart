enum HwAcc {
  auto,
  disabled,
  decoding,
  full,
}
