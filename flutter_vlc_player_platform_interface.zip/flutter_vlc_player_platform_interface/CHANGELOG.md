## 2.0.1

- Add Hybrid composition support for Android

## 2.0.0

- Fix Dart analysis warnings
- Refactored enum parameters to follow dart naming convention 

## 1.0.7

- Add VLC http options

## 1.0.6

- Added VLC recording feature

## 1.0.5

- Upgrade to Null Safety

## 1.0.4

- Add VLC subtitle options

## 1.0.3

- Add isSeekable method to platform interface

## 1.0.2

- Improve the interface to support more reliable memory management.

## 1.0.1

- Add pedantic, fix build issues.

## 1.0.0

- Initial open-source release.